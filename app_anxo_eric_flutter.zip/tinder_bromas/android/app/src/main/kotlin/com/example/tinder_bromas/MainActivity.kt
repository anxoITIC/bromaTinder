package com.example.tinder_bromas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
